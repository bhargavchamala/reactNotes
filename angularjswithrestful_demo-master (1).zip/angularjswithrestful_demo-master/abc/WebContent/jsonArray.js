[{"level": "Ankur ", "desc": "Bhadoria"},
 {"level": "ASE", "desc": "Programmer"},
 {"level": "Salary",  "desc": "1000000"},
 {"level": "Location", "desc": "Bangalore"},
];
