[{"level": "Manu ", "desc": "Shrivastava"},
 {"level": "ASE", "desc": "Programmer"},
 {"level": "Salary",  "desc": "1000000"},
 {"level": "Location", "desc": "Raipur"},
];
