[{"level": "Amanjot ", "desc": "Singh"},
 {"level": "ASE", "desc": "Programmer"},
 {"level": "Salary",  "desc": "10000"},
 {"level": "Location", "desc": "Rohtak"},
];
